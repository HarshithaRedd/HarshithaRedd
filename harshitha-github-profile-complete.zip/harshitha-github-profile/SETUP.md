# Setup

Upload these files into the `HarshithaRedd/HarshithaRedd` profile repository while preserving the folders:

```text
README.md
assets/data-story.gif
assets/data-story-static.png
.github/workflows/snake.yml
```

## GitHub web upload

1. Open the `HarshithaRedd/HarshithaRedd` repository.
2. Choose **Add file → Upload files**.
3. Upload `README.md` and the entire `assets` folder contents.
4. Create `.github/workflows/snake.yml` if GitHub's browser uploader does not preserve hidden folders.
5. Commit to the `main` branch.
6. Open **Actions → Generate Contribution Snake → Run workflow**.
7. Confirm that an `output` branch appears.
8. Refresh the GitHub profile.

The banner URL used by the README is:

```text
https://raw.githubusercontent.com/HarshithaRedd/HarshithaRedd/main/assets/data-story.gif
```

It will return 404 until `assets/data-story.gif` exists on the `main` branch with the exact same spelling and capitalization.
